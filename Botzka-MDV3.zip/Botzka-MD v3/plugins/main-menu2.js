import fetch from 'node-fetch'
import fs from 'fs'
let handler = async (m, { conn, args, command }) => {
  const ultah = new Date('Juli 11 2023 00:0:01')
    const sekarat = new Date().getTime() 
    const Kurang = ultah - sekarat
    const ohari = Math.floor( Kurang / (1000 * 60 * 60 * 24));
    const ojam = Math.floor( Kurang % (1000 * 60 * 60 * 24) / (1000 * 60 * 60))
    const onet = Math.floor( Kurang % (1000 * 60 * 60) / (1000 * 60))
    const detek = Math.floor( Kurang % (1000 * 60) / 1000)
let totalf = Object.values(global.plugins).filter(
    (v) => v.help && v.tags
  ).length;
 await conn.sendButton(m.chat, `---------MENU---------
 Hay kak ${await conn.getName(m.sender)} saya merupakan Bot whatsapp yg di kembangkan oleh Andika XD saya dapat membantu mu kapan pun dan dimana pun kamu berada. Dan saya pun bisa menghilang kan rasa gabut anda ..., Oh iya. Kamu dapat nomor saya dari mana? Sebelum menggunakan Bot ini, kamu harus tau rules nya yah agar tidak ter banned oleh bot. Terima kasih Sudah Menggunakan Botzka-MD\n\nNOTE
•Jangan menelpon Bot
•Jangan Sepam Bot
•Jangan Sepam Fitur yg eror
•Gunakan Bot Dengan Baik & Benar

Group Bot whatsapp
https://chat.whatsapp.com/JB8MQZXiGI4059lnmUawZt
\n`,wm + '\n\n' + botdate, thumbdoc, [['Aʟʟ Mᴇɴᴜ','.? all'],['Lɪsᴛ Mᴇɴᴜ','.listmenu']], m, {
contextInfo: { externalAdReply :{
                        mediaUrl: '',
                        mediaType: 2,
                        description: 'anu',
                        title: `A MIMIR🎧 : ${ohari} Hari ${ojam} Jam ${onet} Menit ${detek} Detik`,
                        body: `Join Grup`,          previewType: 0,
                        thumbnail: await (await fetch(`https://telegra.ph/file/abae15ef77d530d1bcd49.jpg`)).buffer(),
                        sourceUrl: 'https://chat.whatsapp.com/JB8MQZXiGI4059lnmUawZt'
                      }}
})
}


handler.help = ['menu']
handler.tags = ['Andika']
handler.command = /^(menu|help|co)$/i
handler.register = false

export default handler