// YURI
global.hyuri = [
'https://telegra.ph/file/5d908f4a17515a15c6202.jpg',
'https://telegra.ph/file/e96c7b42a2d188018dc6c.png'
]

   // LOLI PIRANG
global.hLokun = [
'https://telegra.ph/file/8902f4fc550727a62e99f.jpg',
'https://telegra.ph/file/6a6a40e924c16a8f0de03.jpg',
'https://telegra.ph/file/b035d3038a0b124f1d846.jpg',
'https://telegra.ph/file/9d475f7852bf6f6193c80.jpg'
]

      // LOLI
global.hloli = [
'https://telegra.ph/file/872c360a7104d86752650.jpg',
'https://telegra.ph/file/f6bbb53620374257bfa51.jpg',
'https://telegra.ph/file/9b76375f3869440818d57.jpg',
'https://telegra.ph/file/a78443f0ee887f46808d7.jpg',
'https://telegra.ph/file/e13cf5bb69e77694e080d.png',
'https://telegra.ph/file/eff5bd9d5befd4c31d3b9.png'
]

     // NEKO
global.hneko = [
'https://telegra.ph/file/805a37b1e9a963e7d7ecf.jpg',
'https://telegra.ph/file/f9c4d97477b647cf57a2b.jpg',
'https://telegra.ph/file/b6905b77e6c7732592a13.jpg',
'https://telegra.ph/file/9f82c432d0ba4cfffda9a.png',
'https://telegra.ph/file/484083949d4bfd763b8cf.jpg',
'https://telegra.ph/file/56d4b993754e24c5436c1.jpg',
'https://telegra.ph/file/65a3371c6c7175a34fac0.jpg',
'https://telegra.ph/file/984706b5943cf876633cf.jpg'
]

      // BUNNY
global.hbunny = [
'https://telegra.ph/file/2b71a8d46d29351479fbc.jpg',
'https://telegra.ph/file/ae610571b62b5ab876e9c.jpg', 
'https://telegra.ph/file/cc8255d5b989eef587af2.jpg',
'https://telegra.ph/file/30d2e7375996abd9cfee3.jpg', 
'https://telegra.ph/file/78980c90c44a95a1d30fa.jpg', 
'https://telegra.ph/file/2ac5d8ccf23e73eaa5bfa.jpg',
'https://telegra.ph/file/e7459fffbdc9901bb03ae.jpg'
]

       // BEACH
global.hbeach = [
'https://telegra.ph/file/14ae0ba2da77d74e6b80c.jpg', 
'https://telegra.ph/file/b6905b77e6c7732592a13.jpg',
'https://telegra.ph/file/9da45a352eb4c40e5d641.jpg', 
'https://telegra.ph/file/59e78846ee365975ee6e3.jpg',
'https://telegra.ph/file/1bf7dee46b83eb4c41d7d.jpg',
'https://telegra.ph/file/0525a7929f819cb8278f3.jpg'
]

       // TRAP
global.htrap = [
'https://telegra.ph/file/4b2f8aed0dfbca0471b36.jpg',
'https://telegra.ph/file/65a3371c6c7175a34fac0.jpg',
'https://telegra.ph/file/f74a4729f77a64f4dbac4.jpg',
'https://telegra.ph/file/350a23734b20fe25d56f5.jpg',
'https://telegra.ph/file/d0daf3bca0753775efe6b.jpg'
]
 
       // FURY
global.hfury = [
'https://telegra.ph/file/f390a5d04555daab44132.jpg'
]
