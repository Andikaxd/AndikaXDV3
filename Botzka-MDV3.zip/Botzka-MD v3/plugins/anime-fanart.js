import fetch from 'node-fetch' 
  
 let handler = async (m, { conn, command }) => { 
         let url = 'https://api.lolhuman.xyz/api/random/art?apikey=8e66d0934cf741bfd2182c16' 
         conn.sendButton(m.chat, 'Nih FanArtnya ', wm, await(await fetch(url)).buffer(), [['Next',`.${command}`]],m) 
 } 
 handler.command = /^(fanart)$/i 
 handler.tags = ['anime'] 
 handler.help = ['fanart'] 
 handler.limit = true 
 handler.premium = true 
 export default handler